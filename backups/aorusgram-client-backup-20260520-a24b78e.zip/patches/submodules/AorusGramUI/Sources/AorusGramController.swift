import Foundation
import UIKit
import Display
import SwiftSignalKit
import Postbox
import TelegramCore
import TelegramPresentationData
import ItemListUI
import PresentationDataUtils
import AccountContext

// MARK: - Sections

private enum AorusSection: Int32 {
    case privacy
    case ai
    case performance
    case ui
    case antiSpoof
    case aorusCode
    case channel
}

// MARK: - State

private struct AorusState: Equatable {
    var ghostMode: Bool
    var blockReadReceipts: Bool
    var hideTyping: Bool
    var saveDeletedMessages: Bool
    var antiScreenshot: Bool
    var voiceTranscription: Bool
    var chatSummary: Bool
    var translator: Bool
    var autoReply: Bool
    var downloadAccel: Bool
    var antiSpamEnabled: Bool
    var streaks: Bool
    var glassUI: Bool
    var siriShortcuts: Bool
    var antiSpoofDeleted: Bool
    var antiSpoofOnline: Bool
    var aorusCodeEnabled: Bool
}

// MARK: - Arguments

private final class AorusArguments {
    let set: (WritableKeyPath<AorusState, Bool>, Bool) -> Void
    let openChannel: () -> Void
    let clearCache: () -> Void

    init(set: @escaping (WritableKeyPath<AorusState, Bool>, Bool) -> Void,
         openChannel: @escaping () -> Void,
         clearCache: @escaping () -> Void) {
        self.set = set
        self.openChannel = openChannel
        self.clearCache = clearCache
    }
}

// MARK: - Entries

private enum AorusEntry: ItemListNodeEntry {
    case privacyHeader(PresentationTheme, String)
    case ghostMode(PresentationTheme, String, Bool)
    case saveDeletedMessages(PresentationTheme, String, Bool)
    case clearDeletedCache(PresentationTheme, String)
    case antiScreenshot(PresentationTheme, String, Bool)

    case aiHeader(PresentationTheme, String)
    case voiceTranscription(PresentationTheme, String, Bool)
    case chatSummary(PresentationTheme, String, Bool)
    case translator(PresentationTheme, String, Bool)
    case autoReply(PresentationTheme, String, Bool)

    case perfHeader(PresentationTheme, String)
    case downloadAccel(PresentationTheme, String, Bool)
    case antiSpam(PresentationTheme, String, Bool)
    case streaks(PresentationTheme, String, Bool)

    case uiHeader(PresentationTheme, String)
    case glassUI(PresentationTheme, String, Bool)
    case siriShortcuts(PresentationTheme, String, Bool)

    case antiSpoofHeader(PresentationTheme, String)
    case antiSpoofDeleted(PresentationTheme, String, Bool)
    case antiSpoofOnline(PresentationTheme, String, Bool)

    case aorusCodeHeader(PresentationTheme, String)
    case aorusCodeEnabled(PresentationTheme, String, Bool)

    case officialChannel(PresentationTheme, String)

    var section: ItemListSectionId {
        switch self {
        case .privacyHeader, .ghostMode, .saveDeletedMessages, .clearDeletedCache, .antiScreenshot:
            return AorusSection.privacy.rawValue
        case .aiHeader, .voiceTranscription, .chatSummary, .translator, .autoReply:
            return AorusSection.ai.rawValue
        case .perfHeader, .downloadAccel, .antiSpam, .streaks:
            return AorusSection.performance.rawValue
        case .uiHeader, .glassUI, .siriShortcuts:
            return AorusSection.ui.rawValue
        case .antiSpoofHeader, .antiSpoofDeleted, .antiSpoofOnline:
            return AorusSection.antiSpoof.rawValue
        case .aorusCodeHeader, .aorusCodeEnabled:
            return AorusSection.aorusCode.rawValue
        case .officialChannel:
            return AorusSection.channel.rawValue
        }
    }

    var stableId: Int32 {
        switch self {
        case .privacyHeader:        return 0
        case .ghostMode:            return 1
        case .saveDeletedMessages:  return 4
        case .clearDeletedCache:    return 5
        case .antiScreenshot:       return 6
        case .aiHeader:             return 10
        case .voiceTranscription:   return 11
        case .chatSummary:          return 13
        case .translator:           return 14
        case .autoReply:            return 16
        case .perfHeader:           return 20
        case .downloadAccel:        return 21
        case .antiSpam:             return 22
        case .streaks:              return 23
        case .uiHeader:             return 30
        case .glassUI:              return 31
        case .siriShortcuts:        return 32
        case .antiSpoofHeader:      return 50
        case .antiSpoofDeleted:     return 51
        case .antiSpoofOnline:      return 52
        case .aorusCodeHeader:      return 60
        case .aorusCodeEnabled:     return 61
        case .officialChannel:      return 70
        }
    }

    static func < (lhs: AorusEntry, rhs: AorusEntry) -> Bool {
        return lhs.stableId < rhs.stableId
    }

    static func == (lhs: AorusEntry, rhs: AorusEntry) -> Bool {
        switch lhs {
        case let .privacyHeader(lt, ls):
            if case let .privacyHeader(rt, rs) = rhs { return lt === rt && ls == rs }
        case let .ghostMode(lt, ls, lv):
            if case let .ghostMode(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .saveDeletedMessages(lt, ls, lv):
            if case let .saveDeletedMessages(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .clearDeletedCache(lt, ls):
            if case let .clearDeletedCache(rt, rs) = rhs { return lt === rt && ls == rs }
        case let .antiScreenshot(lt, ls, lv):
            if case let .antiScreenshot(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .aiHeader(lt, ls):
            if case let .aiHeader(rt, rs) = rhs { return lt === rt && ls == rs }
        case let .voiceTranscription(lt, ls, lv):
            if case let .voiceTranscription(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .chatSummary(lt, ls, lv):
            if case let .chatSummary(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .translator(lt, ls, lv):
            if case let .translator(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .autoReply(lt, ls, lv):
            if case let .autoReply(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .perfHeader(lt, ls):
            if case let .perfHeader(rt, rs) = rhs { return lt === rt && ls == rs }
        case let .downloadAccel(lt, ls, lv):
            if case let .downloadAccel(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .antiSpam(lt, ls, lv):
            if case let .antiSpam(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .streaks(lt, ls, lv):
            if case let .streaks(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .uiHeader(lt, ls):
            if case let .uiHeader(rt, rs) = rhs { return lt === rt && ls == rs }
        case let .glassUI(lt, ls, lv):
            if case let .glassUI(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .siriShortcuts(lt, ls, lv):
            if case let .siriShortcuts(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .antiSpoofHeader(lt, ls):
            if case let .antiSpoofHeader(rt, rs) = rhs { return lt === rt && ls == rs }
        case let .antiSpoofDeleted(lt, ls, lv):
            if case let .antiSpoofDeleted(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .antiSpoofOnline(lt, ls, lv):
            if case let .antiSpoofOnline(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .aorusCodeHeader(lt, ls):
            if case let .aorusCodeHeader(rt, rs) = rhs { return lt === rt && ls == rs }
        case let .aorusCodeEnabled(lt, ls, lv):
            if case let .aorusCodeEnabled(rt, rs, rv) = rhs { return lt === rt && ls == rs && lv == rv }
        case let .officialChannel(lt, ls):
            if case let .officialChannel(rt, rs) = rhs { return lt === rt && ls == rs }
        }
        return false
    }

    func item(presentationData: ItemListPresentationData, arguments: Any) -> ListViewItem {
        let args = arguments as! AorusArguments
        switch self {
        case let .privacyHeader(_, text):
            return ItemListSectionHeaderItem(presentationData: presentationData, text: text, sectionId: section)
        case let .ghostMode(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.ghostMode, $0) })
        case let .saveDeletedMessages(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.saveDeletedMessages, $0) })
        case let .clearDeletedCache(_, title):
            return ItemListActionItem(presentationData: presentationData, title: title, kind: .destructive, alignment: .natural, sectionId: section, style: .blocks, action: args.clearCache)
        case let .antiScreenshot(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.antiScreenshot, $0) })
        case let .aiHeader(_, text):
            return ItemListSectionHeaderItem(presentationData: presentationData, text: text, sectionId: section)
        case let .voiceTranscription(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.voiceTranscription, $0) })
        case let .chatSummary(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.chatSummary, $0) })
        case let .translator(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.translator, $0) })
        case let .autoReply(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.autoReply, $0) })
        case let .perfHeader(_, text):
            return ItemListSectionHeaderItem(presentationData: presentationData, text: text, sectionId: section)
        case let .downloadAccel(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.downloadAccel, $0) })
        case let .antiSpam(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.antiSpamEnabled, $0) })
        case let .streaks(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.streaks, $0) })
        case let .uiHeader(_, text):
            return ItemListSectionHeaderItem(presentationData: presentationData, text: text, sectionId: section)
        case let .glassUI(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.glassUI, $0) })
        case let .siriShortcuts(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.siriShortcuts, $0) })
        case let .antiSpoofHeader(_, text):
            return ItemListSectionHeaderItem(presentationData: presentationData, text: text, sectionId: section)
        case let .antiSpoofDeleted(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.antiSpoofDeleted, $0) })
        case let .antiSpoofOnline(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.antiSpoofOnline, $0) })
        case let .aorusCodeHeader(_, text):
            return ItemListSectionHeaderItem(presentationData: presentationData, text: text, sectionId: section)
        case let .aorusCodeEnabled(_, title, value):
            return ItemListSwitchItem(presentationData: presentationData, title: title, value: value, sectionId: section, style: .blocks, updated: { args.set(\.aorusCodeEnabled, $0) })
        case let .officialChannel(_, title):
            return ItemListActionItem(presentationData: presentationData, title: title, kind: .generic, alignment: .natural, sectionId: section, style: .blocks, action: args.openChannel)
        }
    }
}

// MARK: - Entries builder

private func aorusEntries(state: AorusState, theme: PresentationTheme) -> [AorusEntry] {
    // Privacy section: exactly three rows.
    //   1. Режим призрака — combined toggle that hides online + typing + read receipts
    //      (the per-feature sub-flags blockReadReceipts/hideTyping are still in state
    //       but no longer surfaced; source patches gate on aorusgram_ghost_mode only).
    //   2. Удалённые сообщения — preserves incoming deletes/edits inline in chat.
    //   3. Скрытие экрана при записи — renamed from the ambiguous «Защита от скриншотов».
    // A small destructive 'Очистить кеш удалённых' action sits between (2) and (3) and
    // wipes preserved postbox rows accumulated by the source patches.
    return [
        .privacyHeader(theme, "🔒 ПРИВАТНОСТЬ"),
        .ghostMode(theme, "Режим призрака", state.ghostMode),
        .saveDeletedMessages(theme, "Удалённые сообщения", state.saveDeletedMessages),
        .clearDeletedCache(theme, "🗑 Очистить кеш удалённых"),
        .antiScreenshot(theme, "Скрытие экрана при записи", state.antiScreenshot),

        .aiHeader(theme, "✨ AI ФУНКЦИИ"),
        .voiceTranscription(theme, "Транскрипция войсов", state.voiceTranscription),
        .chatSummary(theme, "Саммари чата", state.chatSummary),
        .translator(theme, "Переводчик", state.translator),
        .autoReply(theme, "Авто-ответчик", state.autoReply),

        .perfHeader(theme, "⚡️ ПРОИЗВОДИТЕЛЬНОСТЬ"),
        .downloadAccel(theme, "Ускоритель загрузок", state.downloadAccel),
        .antiSpam(theme, "Анти-спам", state.antiSpamEnabled),
        .streaks(theme, "Streak счётчик 🔥", state.streaks),

        .uiHeader(theme, "🎨 ИНТЕРФЕЙС"),
        .glassUI(theme, "Glass UI", state.glassUI),
        .siriShortcuts(theme, "Siri Shortcuts", state.siriShortcuts),

        .antiSpoofHeader(theme, "🕵️ АНТИ-СПУФ"),
        .antiSpoofDeleted(theme, "Анти-спуф удалёнок", state.antiSpoofDeleted),
        .antiSpoofOnline(theme, "Анти-спуф онлайна", state.antiSpoofOnline),

        .aorusCodeHeader(theme, "🔐 AORUS CODE"),
        .aorusCodeEnabled(theme, "AorusCode", state.aorusCodeEnabled),

        .officialChannel(theme, "📢 Официальный канал @aorusgram"),
    ]
}

// MARK: - Public factory

public func aorusGramController(context: AccountContext) -> ViewController {
    let mgr   = AorusGramManager.shared
    let spoof = AntiSpoofManager.shared
    let stealth = AorusStealthCodec.shared

    let initialState = AorusState(
        ghostMode:          mgr.ghostMode,
        blockReadReceipts:  mgr.blockReadReceipts,
        hideTyping:         mgr.hideTyping,
        saveDeletedMessages: mgr.saveDeletedMessages,
        antiScreenshot:     mgr.antiScreenshot,
        voiceTranscription: mgr.voiceTranscription,
        chatSummary:        mgr.chatSummary,
        translator:         mgr.translator,
        autoReply:          mgr.autoReply,
        downloadAccel:      mgr.downloadAccel,
        antiSpamEnabled:    mgr.antiSpamEnabled,
        streaks:            mgr.streaks,
        glassUI:            mgr.glassUI,
        siriShortcuts:      mgr.siriShortcuts,
        antiSpoofDeleted:   spoof.antiSpoofDeleted,
        antiSpoofOnline:    spoof.antiSpoofOnline,
        aorusCodeEnabled:   stealth.isEnabled
    )
    let statePromise = ValuePromise(initialState, ignoreRepeated: true)
    let stateValue   = Atomic(value: initialState)

    let updateState: ((AorusState) -> AorusState) -> Void = { f in
        statePromise.set(stateValue.modify { f($0) })
    }

    // Weak reference so openChannel can navigate using the controller's nav stack
    weak var weakController: ItemListController?

    let arguments = AorusArguments(
        set: { keyPath, value in
            updateState { current in
                var next = current
                next[keyPath: keyPath] = value
                return next
            }
            // Persist to managers based on which key changed
            let s = stateValue.with { $0 }
            mgr.ghostMode           = s.ghostMode
            mgr.blockReadReceipts   = s.blockReadReceipts
            mgr.hideTyping          = s.hideTyping
            mgr.saveDeletedMessages = s.saveDeletedMessages
            mgr.antiScreenshot      = s.antiScreenshot
            mgr.voiceTranscription  = s.voiceTranscription
            mgr.chatSummary         = s.chatSummary
            mgr.translator          = s.translator
            mgr.autoReply           = s.autoReply
            mgr.downloadAccel       = s.downloadAccel
            mgr.antiSpamEnabled     = s.antiSpamEnabled
            mgr.streaks             = s.streaks
            mgr.glassUI             = s.glassUI
            mgr.siriShortcuts       = s.siriShortcuts
            spoof.antiSpoofDeleted  = s.antiSpoofDeleted
            spoof.antiSpoofOnline   = s.antiSpoofOnline
            stealth.isEnabled       = s.aorusCodeEnabled
        },
        openChannel: { [weak weakController] in
            // Resolve @aorusgram username and navigate to the channel in-app.
            // Falls back to browser if navigation stack is unavailable.
            guard let controller = weakController,
                  let navigationController = controller.navigationController as? NavigationController else {
                context.sharedContext.applicationBindings.openUrl("https://t.me/aorusgram")
                return
            }
            let _ = (context.engine.peers.resolvePeerByName(name: "aorusgram", referrer: nil)
            |> deliverOnMainQueue).start(next: { result in
                guard case let .result(peer) = result, let peer = peer else { return }
                context.sharedContext.navigateToChatController(NavigateToChatControllerParams(
                    navigationController: navigationController,
                    context: context,
                    chatLocation: .peer(peer)
                ))
            })
        },
        clearCache: {
            let stored = (UserDefaults.standard.array(forKey: "aorusgram_preserved_msgs") as? [[String: Int64]]) ?? []
            guard !stored.isEmpty else { return }
            let ids: [MessageId] = stored.compactMap { entry in
                guard let p = entry["peerId"], let m = entry["msgId"], let ns = entry["namespace"] else { return nil }
                return MessageId(peerId: PeerId(p), namespace: Int32(ns), id: Int32(m))
            }
            let _ = (context.account.postbox.transaction { transaction -> Void in
                transaction.deleteMessages(ids, forEachMedia: { _ in })
            } |> deliverOnMainQueue).start(completed: {
                UserDefaults.standard.removeObject(forKey: "aorusgram_preserved_msgs")
            })
        }
    )

    let signal = statePromise.get()
        |> deliverOnMainQueue
        |> map { state -> (ItemListControllerState, (ItemListNodeState, Any)) in
            let presentationData = context.sharedContext.currentPresentationData.with { $0 }
            let entries = aorusEntries(state: state, theme: presentationData.theme)
            let controllerState = ItemListControllerState(
                presentationData: ItemListPresentationData(presentationData),
                title: .text("🔥 AorusGram"),
                leftNavigationButton: nil,
                rightNavigationButton: nil,
                backNavigationButton: ItemListBackButton(title: presentationData.strings.Common_Back)
            )
            let listState = ItemListNodeState(
                presentationData: ItemListPresentationData(presentationData),
                entries: entries,
                style: .blocks
            )
            return (controllerState, (listState, arguments))
        }

    let controller = ItemListController(context: context, state: signal)
    weakController = controller
    return controller
}
